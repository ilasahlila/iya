<!-- General JS Scripts -->
<script src="/sispak/assets/js/jquery.js"></script>
<script src="/sispak/assets/js/popper.min.js"></script>
<script src="/sispak/assets/js/bootstrap.min.js"></script>
<script src="/sispak/assets/js/jquery.nicescroll.min.js"></script>
<script src="/sispak/assets/js/moment.min.js"></script>
<script src="/sispak/assets/admin/js/stisla.js"></script>

<!-- JS Libraies -->

<!-- Template JS File -->
<script src="/sispak/assets/admin/js/scripts.js"></script>
<script src="/sispak/assets/admin/js/custom.js"></script>

<!-- Page Specific JS File -->
<script src="/sispak/assets/admin/js/jquery.dataTables.min.js"></script>
<script src="/sispak/assets/admin/js/dataTables.bootstrap4.min.js"></script>
<script src="/sispak/assets/admin/js/sweetalert.min.js"></script>