<footer class="main-footer">
    <div class="footer-left">
        Dibuat Oleh Putri Dwi Rahayu
    </div>
    <div class="footer-right">
        2022
    </div>
</footer>